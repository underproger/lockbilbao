/* CerrajeroUCR — main.js (vanilla, без зависимостей) */
(function () {
  'use strict';

  /* ---------------- Настройки (из WordPress: window.C24) ---------------- */
  var C24 = window.C24 || {};
  var T = C24.i18n || {};
  var CONFIG = {
    formEndpoint: C24.endpoint || '',
    formFields: C24.form || null,
    token: C24.token || '',
    phone: C24.phone || '',
    phoneHref: C24.phoneHref || ''
  };
  var ZONES = C24.zones || {};
  var AREAS = C24.areas || [];

  var AREA_BY_ID = {};
  AREAS.forEach(function (g) {
    g.items.forEach(function (it) {
      AREA_BY_ID[it[0]] = { id: it[0], name: it[1], zone: it[2], group: g.group };
    });
  });

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $ = function (sel, ctx) { return (ctx || document).querySelector(sel); };
  var $$ = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };

  /* ---------------- Header ---------------- */
  var header = $('[data-header]');
  var mobileBar = $('[data-mobile-bar]');
  var hero = $('[data-hero]') || $('.hero'); // первый экран: после него показываем нижнюю мобильную панель
  var fab = $('[data-fab]'); // плавающие кнопки WhatsApp / «наверх»

  function onScroll() {
    var y = window.scrollY || window.pageYOffset;
    if (header) header.classList.toggle('is-scrolled', y > 10);
    var barVisible = !!(mobileBar && hero && y > hero.offsetHeight * 0.55);
    if (mobileBar) mobileBar.classList.toggle('is-visible', barVisible);
    if (fab) {
      fab.classList.toggle('is-top-visible', y > window.innerHeight * 0.8);
      fab.classList.toggle('is-raised', barVisible); // на телефоне поднимаем над нижней панелью
    }
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------------- Mobile menu ---------------- */
  var burger = $('[data-burger]');
  var menu = $('[data-mobile-menu]');

  function setMenu(open) {
    if (!burger || !menu) return;
    burger.setAttribute('aria-expanded', String(open));
    burger.setAttribute('aria-label', open ? T.menuClose : T.menuOpen);
    menu.hidden = !open;
    document.documentElement.style.overflow = open ? 'hidden' : '';
    if (open) header.classList.add('is-scrolled'); else onScroll();
  }
  if (burger) {
    burger.addEventListener('click', function () {
      setMenu(burger.getAttribute('aria-expanded') !== 'true');
    });
    $$('a', menu).forEach(function (a) { a.addEventListener('click', function () { setMenu(false); }); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && burger.getAttribute('aria-expanded') === 'true') { setMenu(false); burger.focus(); }
    });
    window.matchMedia('(min-width: 1025px)').addEventListener('change', function (e) { if (e.matches) setMenu(false); });
  }

  /* ---------------- Hero: параллакс ---------------- */
  var stageItems = $$('[data-parallax]');
  if (hero && !reduceMotion && window.matchMedia('(hover: hover) and (pointer: fine)').matches && stageItems.length) {
    var raf = null, mx = 0, my = 0;
    hero.addEventListener('pointermove', function (e) {
      var r = hero.getBoundingClientRect();
      mx = (e.clientX - r.left) / r.width - 0.5;
      my = (e.clientY - r.top) / r.height - 0.5;
      if (!raf) raf = requestAnimationFrame(applyParallax);
    });
    hero.addEventListener('pointerleave', function () { mx = 0; my = 0; if (!raf) raf = requestAnimationFrame(applyParallax); });
  }
  function applyParallax() {
    raf = null;
    stageItems.forEach(function (el) {
      var k = parseFloat(el.getAttribute('data-parallax')) || 0;
      el.style.translate = (mx * k).toFixed(1) + 'px ' + (my * k).toFixed(1) + 'px';
    });
  }

  /* ---------------- Слайдер услуг ---------------- */
  $$('[data-slider]').forEach(function (root) {
    var track = $('[data-slider-track]', root);
    var section = root.closest('section') || document;
    var slides = $$('[data-slide]', track);
    var prev = $('[data-slider-prev]', section);
    var next = $('[data-slider-next]', section);
    var curEl = $('[data-slider-current]', section);
    var bar = $('[data-slider-bar]', section);
    if (!track || !slides.length) return;

    var isSlider = function () { return getComputedStyle(track).display === 'flex'; };
    var step = function () {
      var gap = parseFloat(getComputedStyle(track).columnGap) || 0;
      return slides[0].getBoundingClientRect().width + gap;
    };
    var maxScroll = function () { return track.scrollWidth - track.clientWidth; };
    var current = 0;

    function update() {
      if (!isSlider()) return;
      var max = maxScroll();
      var idx = track.scrollLeft >= max - 4 ? slides.length - 1 : Math.round(track.scrollLeft / step());
      idx = Math.max(0, Math.min(slides.length - 1, idx));
      if (idx !== current) {
        slides[current].classList.remove('is-current');
        slides[idx].classList.add('is-current');
        current = idx;
      }
      if (curEl) curEl.textContent = (idx < 9 ? '0' : '') + (idx + 1);
      if (bar) bar.style.width = ((idx + 1) / slides.length * 100).toFixed(2) + '%';
      if (prev) prev.disabled = track.scrollLeft <= 4;
      if (next) next.disabled = track.scrollLeft >= max - 4;
    }

    var ticking = false;
    track.addEventListener('scroll', function () {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(function () { ticking = false; update(); });
    }, { passive: true });
    window.addEventListener('resize', update);

    function go(dir) {
      track.scrollBy({ left: dir * step(), behavior: reduceMotion ? 'auto' : 'smooth' });
    }
    if (prev) prev.addEventListener('click', function () { go(-1); });
    if (next) next.addEventListener('click', function () { go(1); });

    track.addEventListener('keydown', function (e) {
      if (e.target !== track) return;
      if (e.key === 'ArrowRight') { e.preventDefault(); go(1); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); go(-1); }
    });

    // Перетаскивание мышью (тач и трекпад листают нативно)
    var drag = null;
    track.addEventListener('pointerdown', function (e) {
      if (e.pointerType !== 'mouse' || e.button !== 0 || !isSlider()) return;
      e.preventDefault(); // не начинать выделение текста при перетаскивании
      drag = { x: e.clientX, left: track.scrollLeft, moved: false };
    });
    track.addEventListener('dragstart', function (e) { e.preventDefault(); });
    window.addEventListener('pointermove', function (e) {
      if (!drag) return;
      var dx = e.clientX - drag.x;
      if (!drag.moved && Math.abs(dx) > 5) { drag.moved = true; track.classList.add('is-dragging'); }
      if (drag.moved) track.scrollLeft = drag.left - dx;
    });
    window.addEventListener('pointerup', function () {
      if (!drag) return;
      var moved = drag.moved;
      drag = null;
      if (!moved) return;
      track.classList.remove('is-dragging');
      var target = Math.round(track.scrollLeft / step()) * step();
      track.scrollTo({ left: Math.min(target, maxScroll()), behavior: reduceMotion ? 'auto' : 'smooth' });
      // гасим клик по ссылке, который браузер отправит сразу после перетаскивания
      var suppress = function (ev) { ev.preventDefault(); ev.stopPropagation(); };
      track.addEventListener('click', suppress, true);
      setTimeout(function () { track.removeEventListener('click', suppress, true); }, 0);
    });

    // Фокус с клавиатуры на карточке — прокручиваем только трек (не scrollIntoView, он двигает и предков)
    track.addEventListener('focusin', function (e) {
      var li = e.target.closest('[data-slide]');
      if (!li || !isSlider() || !e.target.matches(':focus-visible')) return;
      var left = li.offsetLeft - slides[0].offsetLeft;
      if (left < track.scrollLeft || left + li.offsetWidth > track.scrollLeft + track.clientWidth) {
        track.scrollTo({ left: Math.min(left, maxScroll()), behavior: reduceMotion ? 'auto' : 'smooth' });
      }
    });

    update();
  });

  /* ---------------- Tabs (типы дверей / замков) ---------------- */
  $$('[data-tablist]').forEach(function (list) {
    var tabs = $$('[role="tab"]', list);
    function select(tab, focus) {
      tabs.forEach(function (t) {
        var on = t === tab;
        t.setAttribute('aria-selected', String(on));
        t.tabIndex = on ? 0 : -1;
        var panel = document.getElementById(t.getAttribute('aria-controls'));
        if (panel) panel.hidden = !on;
      });
      if (focus) tab.focus();
    }
    tabs.forEach(function (tab, i) {
      tab.addEventListener('click', function () { select(tab); });
      tab.addEventListener('keydown', function (e) {
        var next = null;
        if (e.key === 'ArrowRight') next = tabs[(i + 1) % tabs.length];
        if (e.key === 'ArrowLeft') next = tabs[(i - 1 + tabs.length) % tabs.length];
        if (e.key === 'Home') next = tabs[0];
        if (e.key === 'End') next = tabs[tabs.length - 1];
        if (next) { e.preventDefault(); select(next, true); }
      });
    });
  });

  /* ---------------- Слайдер отзывов (центральная карточка, по кругу) ---------------- */
  $$('[data-rv]').forEach(function (root) {
    var track = $('[data-rv-track]', root);
    var slides = $$('[data-rv-slide]', track);
    var prev = $('[data-rv-prev]', root);
    var next = $('[data-rv-next]', root);
    var dotsWrap = $('[data-rv-dots]', root.closest('section') || document);
    if (!track || !slides.length) return;

    var n = slides.length;
    var current = -1;
    var dots = [];
    var lock = false, lockTimer; // пока идёт программная прокрутка, активную карточку не пересчитываем
    function unlockSoon() {
      clearTimeout(lockTimer);
      lockTimer = setTimeout(function () { lock = false; setActive(nearest()); }, 160);
    }

    // Позиция прокрутки, при которой слайд i стоит по центру трека
    function offsetFor(i) {
      var s = slides[i];
      return s.offsetLeft + s.offsetWidth / 2 - track.clientWidth / 2;
    }
    function nearest() {
      var c = track.scrollLeft + track.clientWidth / 2, best = 0, dist = Infinity;
      slides.forEach(function (s, i) {
        var d = Math.abs(s.offsetLeft + s.offsetWidth / 2 - c);
        if (d < dist) { dist = d; best = i; }
      });
      return best;
    }
    function setActive(i) {
      if (i === current) return;
      current = i;
      slides.forEach(function (s, k) {
        s.classList.toggle('is-active', k === i);
        s.classList.toggle('is-before', k < i);
        s.classList.toggle('is-after', k > i);
        s.style.setProperty('--d', Math.abs(k - i));
      });
      dots.forEach(function (d, k) {
        if (k === i) d.setAttribute('aria-current', 'true'); else d.removeAttribute('aria-current');
      });
    }
    function goTo(i, instant) {
      i = (i + n) % n; // по кругу: с последнего на первый и обратно
      setActive(i);
      lock = true;
      unlockSoon();
      track.scrollTo({ left: offsetFor(i), behavior: instant || reduceMotion ? 'auto' : 'smooth' });
    }

    if (dotsWrap) {
      slides.forEach(function (s, i) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'rv-dots__btn';
        b.setAttribute('aria-label', (T.reviewOf || '%1$s / %2$s').replace('%1$s', i + 1).replace('%2$s', n));
        b.addEventListener('click', function () { goTo(i); });
        dotsWrap.appendChild(b);
        dots.push(b);
      });
    }

    if (prev) prev.addEventListener('click', function () { goTo(current - 1); });
    if (next) next.addEventListener('click', function () { goTo(current + 1); });

    track.addEventListener('keydown', function (e) {
      if (e.target !== track) return;
      if (e.key === 'ArrowRight') { e.preventDefault(); goTo(current + 1); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); goTo(current - 1); }
    });

    var ticking = false;
    track.addEventListener('scroll', function () {
      if (lock) { unlockSoon(); return; }
      if (ticking || drag) return;
      ticking = true;
      requestAnimationFrame(function () { ticking = false; setActive(nearest()); });
    }, { passive: true });

    // Клик по боковой карточке — выводим её в центр
    slides.forEach(function (s, i) {
      s.addEventListener('click', function () { if (i !== current) goTo(i); });
    });

    // Перетаскивание мышью (тач и трекпад листают нативно)
    var drag = null;
    track.addEventListener('pointerdown', function (e) {
      if (e.pointerType !== 'mouse' || e.button !== 0) return;
      e.preventDefault();
      drag = { x: e.clientX, left: track.scrollLeft, moved: false };
    });
    track.addEventListener('dragstart', function (e) { e.preventDefault(); });
    window.addEventListener('pointermove', function (e) {
      if (!drag) return;
      var dx = e.clientX - drag.x;
      if (!drag.moved && Math.abs(dx) > 5) { drag.moved = true; track.classList.add('is-dragging'); }
      if (drag.moved) track.scrollLeft = drag.left - dx;
    });
    window.addEventListener('pointerup', function () {
      if (!drag) return;
      var moved = drag.moved;
      drag = null;
      if (!moved) return;
      track.classList.remove('is-dragging');
      current = -1;
      goTo(nearest());
      var suppress = function (ev) { ev.preventDefault(); ev.stopPropagation(); };
      track.addEventListener('click', suppress, true);
      setTimeout(function () { track.removeEventListener('click', suppress, true); }, 0);
    });

    var resizeTimer;
    window.addEventListener('resize', function () {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(function () { var i = current; current = -1; goTo(i, true); }, 120);
    });

    // Старт с карточки ближе к середине: слева и справа сразу видны соседние отзывы
    goTo(Math.floor((n - 1) / 2), true);
  });

  /* ---------------- FAQ: одна открытая панель ---------------- */
  var acc = $('[data-accordion]');
  if (acc) {
    $$('details', acc).forEach(function (d) {
      d.addEventListener('toggle', function () {
        if (!d.open) return;
        $$('details', acc).forEach(function (o) { if (o !== d) o.open = false; });
      });
    });
  }

  /* ---------------- Селекты районов ---------------- */
  $$('[data-area-select]').forEach(function (sel) {
    AREAS.forEach(function (g) {
      var og = document.createElement('optgroup');
      og.label = g.group;
      g.items.forEach(function (it) {
        var o = document.createElement('option');
        o.value = it[0];
        o.textContent = it[1];
        og.appendChild(o);
      });
      sel.appendChild(og);
    });
  });

  /* ---------------- Проверка района ---------------- */
  var checker = $('[data-area-checker]');
  var checkerResult = $('[data-checker-result]');
  var checkerIdle = checkerResult ? checkerResult.innerHTML : '';

  function renderCheck(id) {
    if (!checkerResult) return;
    var a = AREA_BY_ID[id];
    if (!a) {
      checkerResult.innerHTML = checkerIdle;
      return;
    }
    var z = ZONES[a.zone];
    if (!z) return;
    checkerResult.innerHTML = '<b>' + a.name + ': ' + z.title.toLowerCase() + '.</b> ' + z.text;
  }
  if (checker) checker.addEventListener('change', function () { renderCheck(checker.value); });

  /* ---------------- Модалка ---------------- */
  $$('[data-modal-open]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var dlg = document.getElementById(btn.getAttribute('data-modal-open'));
      if (!dlg) return;
      if (typeof dlg.showModal === 'function') {
        dlg.showModal();
        var first = $('input[type="tel"]', dlg);
        if (first) first.focus();
      } else {
        // браузеры без <dialog> — ведём к основной форме
        location.hash = '#request';
      }
    });
  });
  $$('dialog').forEach(function (dlg) {
    $$('[data-modal-close]', dlg).forEach(function (b) { b.addEventListener('click', function () { dlg.close(); }); });
    dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
  });

  /* ---------------- Формы ---------------- */
  var DIAL_CODES = ['+380', '+351', '+34', '+33', '+44', '+49', '+39', '+48', '+40'];

  $$('[data-lead-form]').forEach(function (form) {
    var phone = $('input[type="tel"]', form);
    var dial = $('[data-dial]', form);
    var errEl = phone ? document.getElementById(phone.getAttribute('aria-describedby')) : null;
    var fileInput = $('[data-file]', form);
    var status = $('[data-form-status]', form);
    var consent = $('input[name="consent"]', form);

    // Автовыбор кода страны, если номер вставили с «+»
    if (phone && dial) {
      phone.addEventListener('input', function () {
        var v = phone.value.replace(/[^\d+]/g, '');
        if (v.charAt(0) === '+') {
          var matched = false;
          for (var i = 0; i < DIAL_CODES.length; i++) {
            if (v.indexOf(DIAL_CODES[i]) === 0) {
              dial.value = DIAL_CODES[i];
              v = v.slice(DIAL_CODES[i].length);
              matched = true;
              break;
            }
          }
          if (!matched) return; // код ещё вводится — не трогаем поле
          phone.value = v;
        } else if (v.indexOf('0034') === 0) {
          dial.value = '+34';
          phone.value = v = v.slice(4);
        }
        if (dial.value === '+34') phone.value = formatEs(v);
        if (phone.getAttribute('aria-invalid') === 'true') validatePhone();
      });
      phone.addEventListener('blur', function () { if (phone.value) validatePhone(); });
    }

    function formatEs(v) {
      var d = v.replace(/\D/g, '').slice(0, 9);
      return d.replace(/^(\d{3})(\d{0,3})(\d{0,3}).*/, function (_, a, b, c) {
        return [a, b, c].filter(Boolean).join(' ');
      });
    }

    function validatePhone() {
      var digits = phone.value.replace(/\D/g, '');
      var msg = '';
      if (!digits) msg = T.phoneEmpty;
      else if (phone.value.trim().charAt(0) === '+') msg = T.phonePlus;
      else if (dial && dial.value === '+34' && !/^[6789]\d{8}$/.test(digits)) msg = T.phoneEs;
      else if (digits.length < 6 || digits.length > 14) msg = T.phoneLen;
      phone.setAttribute('aria-invalid', msg ? 'true' : 'false');
      if (errEl) { errEl.textContent = msg; errEl.hidden = !msg; }
      return !msg;
    }

    if (fileInput) {
      var label = form.querySelector('label[for="' + fileInput.id + '"]');
      var nameEl = label ? $('[data-file-name]', label) : null;
      var defaultName = nameEl ? nameEl.textContent : '';
      if (nameEl) nameEl.setAttribute('data-default', defaultName);
      fileInput.addEventListener('change', function () {
        var f = fileInput.files && fileInput.files[0];
        if (f && f.size > 10 * 1024 * 1024) {
          fileInput.value = '';
          f = null;
          setStatus(T.fileBig, 'error');
        }
        if (label) label.classList.toggle('has-file', !!f);
        if (nameEl) nameEl.textContent = f ? f.name : defaultName;
      });
    }

    function setStatus(text, type) {
      if (!status) return;
      status.textContent = text;
      status.className = 'form-status' + (type ? ' is-' + type : '');
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      setStatus('');
      var ok = phone ? validatePhone() : true;
      if (consent) {
        var cl = consent.closest('.consent');
        if (cl) cl.classList.toggle('is-invalid', !consent.checked);
        if (!consent.checked && ok) { setStatus(T.consent, 'error'); ok = false; }
      }
      if (!ok) { if (phone && phone.getAttribute('aria-invalid') === 'true') phone.focus(); return; }

      var data = new FormData(form);
      data.set('phone_full', (dial ? dial.value : '') + ' ' + phone.value);
      data.set('page', location.href);
      // UTM-метки из URL — для учёта рекламы
      new URLSearchParams(location.search).forEach(function (v, k) { if (/^utm_/.test(k)) data.set(k, v); });

      form.classList.add('is-loading');
      var done = function () {
        form.classList.remove('is-loading');
        form.reset();
        $$('.file', form).forEach(function (l) { l.classList.remove('has-file'); });
        $$('[data-file-name]', form).forEach(function (n) { n.textContent = n.getAttribute('data-default') || ''; });
        setStatus(T.sent, 'success');
      };
      var fail = function () {
        form.classList.remove('is-loading');
        setStatus(T.failed + ' ' + CONFIG.phone, 'error');
      };

      if (!CONFIG.formEndpoint) { setTimeout(done, 600); return; }
      // Служебные поля Contact Form 7 (форма «CerrajeroUCR — заявка»)
      if (CONFIG.formFields) Object.keys(CONFIG.formFields).forEach(function (k) { data.set(k, CONFIG.formFields[k]); });
      if (consent && consent.checked) data.set('consent', '1');
      // Антиспам темы: метку ставит только браузер с JavaScript (см. inc/cf7.php)
      if (CONFIG.token) data.set('c24_token', CONFIG.token);
      fetch(CONFIG.formEndpoint, { method: 'POST', body: data, credentials: 'same-origin' })
        .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
        .then(function (res) {
          if (res && res.status === 'mail_sent') { done(); return; }
          if (res && res.status === 'validation_failed' && phone && (res.invalid_fields || []).some(function (f) { return f.field === 'phone'; })) {
            form.classList.remove('is-loading');
            phone.setAttribute('aria-invalid', 'true');
            if (errEl) { errEl.textContent = T.phoneLen; errEl.hidden = false; }
            phone.focus();
            return;
          }
          fail();
        })
        .catch(fail);
    });
  });

  /* ---------------- Кнопка «наверх» ---------------- */
  $$('[data-to-top]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
      var logo = $('.header .logo');
      if (logo) logo.focus({ preventScroll: true });
    });
  });

  /* ---------------- SEO-текст: «Показать больше» ---------------- */
  $$('[data-more]').forEach(function (box) {
    var body = $('[data-more-body]', box);
    var btn = $('[data-more-btn]', box);
    if (!body || !btn) return;
    var label = $('[data-more-label]', btn);
    box.classList.add('is-ready');
    // текст короче свёрнутой высоты — сворачивать нечего
    if (body.scrollHeight <= body.clientHeight + 40) { box.classList.remove('is-ready'); return; }
    btn.hidden = false;

    function setOpen(open) {
      box.classList.toggle('is-open', open);
      btn.setAttribute('aria-expanded', String(open));
      if (label) label.textContent = open ? T.less : T.more;
      body.style.maxHeight = body.scrollHeight + 'px';
      if (!open) {
        void body.offsetHeight; // фиксируем текущую высоту, чтобы анимация пошла от неё
        body.style.maxHeight = '';
        if (box.getBoundingClientRect().top < 0) box.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
      }
    }
    body.addEventListener('transitionend', function (e) {
      if (e.propertyName === 'max-height' && box.classList.contains('is-open')) body.style.maxHeight = 'none';
    });
    btn.addEventListener('click', function () { setOpen(!box.classList.contains('is-open')); });
    // переход по Tab на ссылку внутри свёрнутого текста — раскрываем
    body.addEventListener('focusin', function () { if (!box.classList.contains('is-open')) setOpen(true); });
  });

  /* ---------------- Год в футере ---------------- */
  var y = $('[data-year]');
  if (y) y.textContent = new Date().getFullYear();
})();
